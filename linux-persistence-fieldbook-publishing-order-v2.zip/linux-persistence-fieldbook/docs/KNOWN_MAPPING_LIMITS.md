# ATT&CK mapping boundaries and source corrections

- The supplied HADESS PDF has a useful Linux overview, but it conflates **mechanism** with **ATT&CK technique**. A technique can have multiple distinct attacker procedures.
- `cron` and `systemd timers` are T1053.003 and T1053.006 respectively; systemd **services** use T1543.002.
- `.bashrc`, `.profile`, aliases and login scripts commonly fall under T1546.004 rather than being separate MITRE IDs.
- Git hooks have no dedicated Linux ATT&CK sub-technique at the time of writing; Elastic labels them broadly T1546 (Event Triggered Execution). Do not misuse T1176 (Software Extensions) simply because Git has hooks.
- `LD_PRELOAD` dynamic linker hijacking is T1574.006, which the current Linux Persistence column does not list as an independent Persistence technique. A loader modification can be part of a persistence chain when paired with a durable trigger.
- `SUID` on a shell script is **not** a correct standalone Linux persistence example. Linux generally ignores script setuid bits, and privilege escalation is a different goal from surviving reboot.
- `auditd`, `bpftrace`, `seccomp`, generic syscalls, `trap` cleanup, environment variable tuning and database triggers are **not** all automatically independent Persistence mechanisms. Trigger, durable state, and access continuity must be demonstrated.
- Container and Kubernetes mechanisms may be in ATT&CK's Containers platform but not the Linux **host** matrix. They are kept in a marked adjacent backlog, not double-counted in 34 Linux terminal entries.

MITRE Linux matrix: https://attack.mitre.org/matrices/enterprise/linux/
Git hook mapping: https://www.elastic.co/security-labs/threat-command/sequel-on-persistence-mechanisms
Linux execve behavior: https://man7.org/linux/man-pages/man2/execve.2.html
