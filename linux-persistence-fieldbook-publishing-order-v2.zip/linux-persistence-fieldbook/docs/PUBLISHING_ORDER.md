# Linux Persistence Fieldbook — Publication Order v2

Date: 2026-11-21

Editorial priority, NOT an ATT&CK frequency ranking. 74 planned **procedure / research topics**, not 74 independently verified MITRE techniques.
Old IDs are retained; the v1 educational order is archived in `catalog/publication_order_v1_educational.csv`.
New order #001 is prior order #039 (`LP-EVE-10`).

## Why #001?

- Python `.pth` startup mechanisms are formally covered by MITRE ATT&CK T1546.018 and its DET0258 detection strategy.
- The malicious `litellm_init.pth` from the March 2026 LiteLLM supply-chain incident provides a public, real-world example (Trend Micro).
- Hands-on lab can demonstrate behavior without network payloads and correlate file modifications, Python startup, and auditd/process evidence.
- Precise caveat: `.pth` import-line execution depends on site initialization and relevant site directories being processed; `python -S` typically disables `site` processing. Do not claim universal execution.

- Python 3.15 (PEP 829) introduces `.start` files and deprecates executable `.pth` import lines; the first article will contrast versions. See https://peps.python.org/pep-0829/ .

## Full queue

| New | Old | Topic | MITRE | Procedure ID |
|---:|---:|---|---|---|
| 001 | 39 | Python .pth Startup Hook — Code Before the Script | T1546.018 | LP-EVE-10 |
| 002 | 10 | systemd System Service — Disguised Boot Persistence | T1543.002 | LP-SER-01 |
| 003 | 48 | PAM pam_exec — Authentication-Triggered Execution | T1556.003 | LP-AUT-03 |
| 004 | 51 | ld.so.preload — Persistent Library Injection | T1574.006 | LP-BIN-03 |
| 005 | 13 | systemd Drop-in — Service Override Hijack | T1543.002 | LP-SER-04 |
| 006 | 37 | Python sitecustomize.py — Silent Startup Execution | T1546.018 | LP-EVE-08 |
| 007 | 40 | APT Hooks — Execution During Package Operations | T1546.016 | LP-APP-04 |
| 008 | 70 | Kubernetes CronJob — Cluster-Level Scheduled Persistence | T1053.007 | LP-CON-02 |
| 009 | 18 | SSH authorized_keys — Reusable Access | T1098.004 | LP-IDE-03 |
| 010 | 35 | udev Rules — Device-Triggered Execution | T1546.017 | LP-EVE-06 |
| 011 | 43 | Git Hooks — Persistence in Developer Workflows | T1546 | LP-APP-01 |
| 012 | 71 | Kubernetes RBAC — Persistent Cluster Access | T1098.006 | LP-CON-03 |
| 013 | 26 | Bash .bashrc — Shell Startup Persistence | T1546.004 | LP-EVE-01 |
| 014 | 55 | Web Shell — Server-Side Access Persistence | T1505.003 | LP-WEB-01 |
| 015 | 06 | systemd Timers — Scheduled Service Execution | T1053.006 | LP-SCH-06 |
| 016 | 01 | User Crontab — Scheduled Execution Without Root | T1053.003 | LP-SCH-01 |
| 017 | 11 | User systemd Service — Per-User Persistence | T1543.002 | LP-SER-02 |
| 018 | 46 | PAM Configuration — Authentication Stack Modification | T1556.003 | LP-AUT-01 |
| 019 | 52 | LD_PRELOAD — Startup Environment Hijack | T1574.006 | LP-BIN-04 |
| 020 | 38 | Python usercustomize.py — User-Level Startup Hook | T1546.018 | LP-EVE-09 |
| 021 | 53 | PATH Hijacking — Executable Search Precedence | T1574.007 | LP-BIN-05 |
| 022 | 42 | Package Maintainer Scripts — Lifecycle Execution | T1546.016 | LP-APP-05 |
| 023 | 12 | systemd ExecStart — Existing Service Hijack | T1543.002 | LP-SER-03 |
| 024 | 47 | PAM Shared Library — Authentication Module Tampering | T1556.003 | LP-AUT-02 |
| 025 | 41 | Package Installation Hooks — Installer-Triggered Execution | T1546.016 | LP-EVE-11 |
| 026 | 45 | Application Extensions — Persistent Auto-load | T1176 | LP-APP-03 |
| 027 | 23 | Privileged Groups — Account Permission Modification | T1098.007 | LP-IDE-06 |
| 028 | 21 | Local User Creation — Persistent Login | T1136.001 | LP-IDE-01 |
| 029 | 62 | Kernel Modules — Boot-Time Load and Reuse | T1547.006 | LP-KER-01 |
| 030 | 33 | XDG User Autostart — Desktop Session Persistence | T1547.013 | LP-BOO-01 |
| 031 | 49 | Binary Replacement — Host Tool Tampering | T1554 | LP-BIN-01 |
| 032 | 57 | Database Stored Procedures — Server-Side Persistence | T1505.001 | LP-WEB-03 |
| 033 | 72 | Container Image — Persistence Across Redeployments | T1525 | LP-CON-04 |
| 034 | 69 | Container Service — Daemon-Level Service Modification | T1543.005 | LP-CON-01 |
| 035 | 44 | Git Pager — Config-Triggered Execution | T1546 | LP-APP-02 |
| 036 | 07 | systemd Timer Hijack — Existing Timer Modification | T1053.006 | LP-SCH-07 |
| 037 | 08 | systemd Transient Timers — Runtime Scheduling | T1053.006 | LP-SCH-08 |
| 038 | 09 | at — One-Time Delayed Execution | T1053.002 | LP-SCH-09 |
| 039 | 02 | Root Crontab — Privileged Scheduled Job | T1053.003 | LP-SCH-02 |
| 040 | 03 | cron.d — System-Wide Scheduled Entry | T1053.003 | LP-SCH-03 |
| 041 | 04 | /etc/crontab — Direct Schedule Modification | T1053.003 | LP-SCH-04 |
| 042 | 05 | Periodic Cron Directories — Scheduled Script Drop | T1053.003 | LP-SCH-05 |
| 043 | 14 | systemd Linked Units — External Unit Loading | T1543.002 | LP-SER-05 |
| 044 | 15 | systemd Wants Symlinks — Unit Enablement | T1543.002 | LP-SER-06 |
| 045 | 16 | rc.local — Legacy Boot Execution | T1037.004 | LP-SER-07 |
| 046 | 17 | SysV Init Scripts — Legacy Service Persistence | T1037.004 | LP-SER-08 |
| 047 | 19 | Root authorized_keys — Privileged SSH Access | T1098.004 | LP-IDE-04 |
| 048 | 20 | authorized_keys File Replacement — Access Preservation | T1098.004 | LP-IDE-05 |
| 049 | 22 | Service Account Creation — Disguised Local Identity | T1136.001 | LP-IDE-02 |
| 050 | 24 | Valid Local Accounts — Continued Access | T1078.003 | LP-IDE-08 |
| 051 | 25 | Existing SSH/VPN Access — External Access Persistence | T1133 | LP-IDE-07 |
| 052 | 27 | Bash Profiles — Login-Shell Execution | T1546.004 | LP-EVE-02 |
| 053 | 28 | Global Shell Profiles — /etc/profile.d | T1546.004 | LP-EVE-03 |
| 054 | 29 | Zsh Startup Files — Shell Initialization | T1546.004 | LP-EVE-04 |
| 055 | 30 | Shell Aliases and Functions — Command Hijacking | T1546.004 | LP-SUP-01 |
| 056 | 31 | Shell Trap — Event-Driven Shell Execution | T1546.005 | LP-EVE-05 |
| 057 | 32 | MOTD Update Scripts — Login-Triggered Execution | T1037 (tentative) | LP-SUP-02 |
| 058 | 34 | XDG Global Autostart — System-Wide GUI Session | T1547.013 | LP-BOO-02 |
| 059 | 36 | udev Rule Hijack — Existing Device Hook | T1546.017 | LP-EVE-07 |
| 060 | 50 | Binary Wrapping — Command Interposition | T1554 | LP-BIN-02 |
| 061 | 54 | Writable Executable Paths — Binary Tampering | T1554 | LP-BIN-06 |
| 062 | 56 | Hidden Web Shell — Application-Tree Implant | T1505.003 | LP-WEB-02 |
| 063 | 58 | Stored Procedure Changes — Database Code Tampering | T1505.001 | LP-WEB-04 |
| 064 | 59 | Database Triggers — Conditional Procedure Invocation | T1505.001 (conditional) | LP-SUP-03 |
| 065 | 60 | Web Server Module — Extension-Based Persistence | T1505 | LP-WEB-05 |
| 066 | 61 | Kernel Module Autoload — Boot Configuration | T1547.006 | LP-BOO-03 |
| 067 | 63 | UEFI/BIOS Firmware — Firmware-Level Persistence | T1542.001 | LP-KER-02 |
| 068 | 64 | Bootkits — Early Boot Execution | T1542.003 | LP-KER-03 |
| 069 | 65 | Peripheral Firmware — Hardware Component Persistence | T1542.002 | LP-KER-04 |
| 070 | 66 | Traffic Signaling — Network Triggering | T1205 | LP-EXT-01 |
| 071 | 67 | External Remote Service — Access Configuration | T1133 | LP-EXT-02 |
| 072 | 68 | OpenVPN Scripts — Session Lifecycle Hooks | T1546 (tentative) | LP-SUP-04 |
| 073 | 73 | Power Settings — Shutdown Resistance | T1653 | LP-AVA-01 |
| 074 | 74 | Exclusive Control — Service/System Lock-In | T1668 | LP-AVA-02 |

## Sources used to prioritize the opening episodes

- MITRE ATT&CK T1546.018: https://attack.mitre.org/techniques/T1546/018/
- MITRE DET0258: https://attack.mitre.org/detectionstrategies/DET0258/
- Trend Micro (2026-03-27): https://success.trendmicro.com/en-US/solution/KA-0022880
- Microsoft (2026-09-30) Zimbra PAM and systemd intrusion: https://www.microsoft.com/en-us/security/blog/2026/09/30/unauthenticated-command-injection-on-internet-facing-mail-servers-tracking-cve-2026-73570/
- SANS (2026-06-30) package compromise and kernel stealth: https://www.sans.org/blog/investigating-ai-tools-modern-linux-intrusions

## Validation rules

Every entry starts as `candidate`. Do not call a scenario `verified` until a controlled execution produces a tested artifact plus a referenced raw log and repeatable detection. Do not claim that every T1574 case is persistence without a persisting trigger. Do not conflate container/firmware with normal Linux host persistence. Clearly separate triggers that require user action (Git hooks, VPN sessions, etc.) from boot/logon/scheduled autostart. Merge duplicate cases when their operational mechanics and evidence do not differ.
