# Article 001 — Python .pth Startup Hook (T1546.018)

**Working headline:** Python `.pth` Persistence: Code Execution Before Your Script Runs

**Prior catalog reference:** #039 / LP-EVE-10

## One-sentence claim

On Linux installations where Python processes `.pth` files in site directories, executable import lines may run before the application’s own script, creating an unexpected startup execution surface.

## Why it is timely

The March 2026 LiteLLM supply-chain compromise involved `litellm_init.pth`, as described by Trend Micro; MITRE also recognizes use by TeamPCP Cloud Stealer and Mini Shai-Hulud. These incidents are case evidence, not a claim about technique frequency.

## 2026 Python compatibility note

Python 3.15 introduced PEP 829 `.start` entry point files; executable import lines in `.pth` have entered a deprecation period and a matching `.start` file suppresses the `.pth` import lines. The article must show this version-dependent behavior, not imply that `.pth` works unchanged forever. Test 3.14 and 3.15 separately where possible.

## Must investigate and verify before publication

1. Python interpreter version, OS/distro, venv/user site distinction; `-S` control comparison.
2. Clear benign lab trigger and repeatable cleanup, avoiding collection of credentials or outbound connections.
3. File creation/modification artifact in site-packages and startup execution trace.
4. auditd/sysmon/EDR process events with full event provenance; raw log citation, timestamps, and environment.
5. Detection based on MITRE DET0258, with expected false positives (legitimate `.pth` import hooks).
6. Limits: no claim that *every* python invocation or interpreter configuration processes the same .pth file.
7. Publish only when repeatable evidence and detection test succeed.

## References

- MITRE: https://attack.mitre.org/techniques/T1546/018/
- MITRE DET0258: https://attack.mitre.org/detectionstrategies/DET0258/
- Python docs: https://docs.python.org/3.14/library/site.html
- Python 3.15 / PEP 829: https://peps.python.org/pep-0829/
- Python 3.15 site docs: https://docs.python.org/3.15/library/site.html
- March 2026 LiteLLM advisory: https://success.trendmicro.com/en-US/solution/KA-0022880
