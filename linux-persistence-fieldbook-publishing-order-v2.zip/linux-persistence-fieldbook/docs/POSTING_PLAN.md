# Social publication checklist

Format, every post:

1. A clear single-sentence claim about the persistence *mechanism*.
2. A trigger and artifact path (distro caveats), ideally with one diagram.
3. One real **lab-captured** event with provenance, or clearly label it unavailable.
4. Detection signal and practical false positives.
5. Reproducibility + cleanup notes and permalink to its dossier.

Do not publish source-less one-liner reverse shells and pretend they teach persistence. First release priority: cron, systemd service, SSH authorized_keys, systemd timer, shell startup. Shoot for verified deliverables rather than daily content quota.
