# T1053.003 — Cron

**Persistence mechanism:** a scheduler launches a command at a recurring time. **What persists** is the schedule/configuration, not the `crontab` command itself.

## Distinct procedures in scope

1. User crontab under system-dependent spool path.
2. Root crontab (higher execution privileges).
3. System crontab `/etc/crontab` (includes account field).
4. Dedicated `/etc/cron.d/` configuration.
5. Script in periodic cron directories where supported.

Use `crontab -l`, the applicable distribution's spool paths and the cron daemon to inventory; do **not** assume one Debian path exists on all distributions. Check parent-child process correlation rather than alerting solely on `crontab -e`.

## Data to capture

- `auditd` writes/attribute changes under watched cron paths; group SYSCALL, PATH, CWD and PROCTITLE on the same audit serial.
- Process creation showing editor/utility and subsequent cron-launched process.
- Relevant syslog/journal entry for job firing; this differs by distribution and logging setup.
- File diffs including owner, permissions, schedule and target path.

## Harmless lab exercise

On a disposable Linux VM, put a known benign timestamp-printing job into a user crontab, capture a complete baseline and modification event, allow a single scheduled execution, then remove it. No network callback or reverse shell is necessary to demonstrate persistence mechanics.

## What counts as strong evidence

1. Change event tied to a watched crontab path.
2. Unexpected schedule or executable path, or unauthorized actor.
3. Later execution by cron with matching command or file path.

**False positives:** configuration management, cron package installation, system administration and normal maintenance. Prefer baseline/versioned inventories and signed change windows.

**Blind spots:** an auditd watch sees *changes* only after it was enabled. It cannot prove a job actually fired. A process-name-only detector misses direct file edits and produces high noise.

References: https://attack.mitre.org/techniques/T1053/003/ · https://research.splunk.com/stories/linux_persistence_techniques/ · https://github.com/splunk/attack_data

Raw captured external test logs: [dataset provenance](../../datasets/SOURCES.md). A small auditd watch-hit parser and its synthetic unit test are included for code testing only.
