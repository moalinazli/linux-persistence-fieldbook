# T1098.004 — SSH Authorized Keys

**Persistence mechanism:** an extra authorized public key provides another future authentication path. Modifying the file alone does not prove the key was used.

## Procedure variants

- Add a key to the existing user's `authorized_keys`.
- Add a key to the root user's `authorized_keys` where that path is in use.
- Replace/rewrite the existing file instead of appending.
- Couple key change with a change to SSH authentication configuration.

## Defender's evidence

1. File write or rename on the `authorized_keys` path (not necessarily a suspicious command line).
2. User/actor/process responsible and key fingerprint delta. **Do not expose full personal keys or secrets.**
3. Subsequent sshd authentication using that principal, and source IP / public-key fingerprint if available.

Alerting only when `bash` or `cat` appears on a command line is an intentionally **partial** detector: Python, Ansible, editors and direct file writes can bypass such a filter without stealth. The alert becomes stronger when file modification and SSH login are correlated.

## Source-backed captured telemetry

Splunk publishes a Sysmon-for-Linux test dataset for this exact technique: [T1098.004 authkey_linux-sysmon.log](https://github.com/splunk/attack_data/blob/master/datasets/attack_techniques/T1098.004/ssh_authorized_keys/authkey_linux-sysmon.log) and a [corresponding detection](https://research.splunk.com/endpoint/f5ab595e-28e5-4327-8077-5008ba97c850/). Its LFS metadata indicates 3,998 bytes; it is **controlled-test telemetry**, not an incident case.

**False positives:** SSH key rotation, authorized deployment automation, user provisioning and break-glass access. Investigate unauthorized changes rather than all key changes.

Reference: https://attack.mitre.org/techniques/T1098/004/
