# T1543.002 — Systemd Service

**Mechanism:** creation/modification of a systemd unit can cause an executable to start on boot, user login, service restart or another unit activation. A `.service` file existing alone is **not proof** it will automatically start.

## Procedure variants

- New system unit in `/etc/systemd/system/`.
- New per-user unit in `~/.config/systemd/user/`.
- Modification of `ExecStart` in an existing unit.
- Drop-in override via `*.service.d/*.conf`.
- Activation via appropriate `.wants/` links; user lingering can affect user-unit behavior.

## High-signal collection

1. File events in unit paths plus ownership and hashes.
2. `systemctl cat <unit>`, `systemctl show <unit>` and `systemctl list-unit-files` inventories.
3. `journalctl -u <unit>` and process parent lineage (systemd / user systemd).
4. Suspicious execution target (unexpected writable location), recent change outside maintenance, and associated network behavior. Do not equate every new service to malware.

**Coverage note:** static unit audit does not cover every transient unit or runtime-only behavior. Confirm enablement, activation and current effective unit configuration.

**Real-world described procedure:** MITRE documents Sandworm configuring a systemd unit for GOGETTER in the 2022 Ukraine electric-power attack. This is a threat report, **not an included raw log**.

Sources: https://attack.mitre.org/techniques/T1543/002/ · https://attack.mitre.org/detectionstrategies/DET0253/ · https://github.com/elastic/detection-rules/blob/main/rules/linux/persistence_systemd_service_creation.toml
