> Editorial update (2026-11-21): the **new** 74-episode publishing order is in [`docs/PUBLISHING_ORDER.md`](docs/PUBLISHING_ORDER.md). First article: Python `.pth` startup hooks; previous educational order archived in `catalog/publication_order_v1_educational.csv`. The topic counts are planning candidates, not verified cases.

# دفترچه عملی Linux Persistence

**این ریپو قرار نیست فهرست ۱۰۰ دستور لینوکس با عنوان جذاب باشد.** هر موضوع باید مکانیزم، شرط اجرا، آثار روی سیستم، لاگ قابل بررسی، Detection و تست داشته باشد.

## تعدادها

- ماتریس فعلی MITRE Linux: **۱۷ تکنیک والد، ۳۰ زیرتکنیک و ۳۴ ورودی نهایی**.
- بک‌لاگ این مخزن: **70 Procedure پیشنهادی**؛ هنوز تأیید آزمایشگاهی نشده‌اند.
- تعداد Procedure واقعی در جهان ثابت نیست و MITRE برای آن عدد کلی اعلام نمی‌کند.

## دو دسته‌بندی جدا

- **رسمی:** TA0003 → Technique → Sub-technique (شناسه MITRE).
- **عملیاتی:** Accounts/SSH، Scheduler، Boot/Service، Shell، Event Hook، Application Extension، PAM، Binary/Loader، Web/DB، Kernel/Firmware، Container، Remote Access.

## برای هر پست

`Mechanism → Trigger → Permissions → Files → Telemetry → Detection → False Positives → Lab Test → Cleanup → References`

## تفکیک شواهد

- `incident-observed`: شواهد انتشار‌یافته از رخداد واقعی با منبع معتبر.
- `lab-captured`: لاگ واقعی، تولیدشده در یک آزمایشگاه یا Attack Range.
- `synthetic-test-only`: داده ساختگی برای Unit Test؛ نباید به‌عنوان لاگ حمله واقعی نمایش داده شود.
- `reference-link-only`: فقط آدرس دیتاست؛ هنوز دانلود/بازبینی نشده.

دو مرجع نمونه معتبر برای Detection و لاگ خام، Splunk Security Content و Splunk Attack Data هستند. اطلاعات دقیق در [SOURCES.md](datasets/SOURCES.md).

**بخش‌های آماده:** [Cron](techniques/T1053.003/README.md)، [SSH Keys](techniques/T1098.004/README.md)، [Systemd](techniques/T1543.002/README.md)، [فهرست تمام Procedureها](catalog/procedure_backlog.csv).


Publication sequence (70 original + 4 PDF gap candidates): [docs/PUBLISHING_ORDER.md](docs/PUBLISHING_ORDER.md). All items are research candidates, not verified attacks.
