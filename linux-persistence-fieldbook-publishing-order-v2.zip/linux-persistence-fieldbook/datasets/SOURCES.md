# Telemetry provenance — no invented logs

The entries below are **references to genuine captured telemetry from controlled tests**, not production incident records. The datasets have not been rehosted in this starter repository.

| Technique | Captured dataset | Type | Approx. raw size | License | Status |
|---|---|---|---|---|---|
| T1053.003 | [Splunk / cronjobs_entry / sysmon_linux.log](https://github.com/splunk/attack_data/blob/master/datasets/attack_techniques/T1053.003/cronjobs_entry/sysmon_linux.log) | Sysmon for Linux; controlled test | 59,662,955 B (Git LFS metadata) | Apache-2.0; check attribution | reference-link-only |
| T1053.003 | [Splunk / crontab_edit_parameter / sysmon_linux.log](https://github.com/splunk/attack_data/blob/master/datasets/attack_techniques/T1053.003/crontab_edit_parameter/sysmon_linux.log) | Sysmon for Linux; controlled test | size unverified | Apache-2.0; check attribution | reference-link-only |
| T1098.004 | [Splunk / ssh_authorized_keys / authkey_linux-sysmon.log](https://github.com/splunk/attack_data/blob/master/datasets/attack_techniques/T1098.004/ssh_authorized_keys/authkey_linux-sysmon.log) | Sysmon for Linux; controlled test | 3,998 B (Git LFS metadata) | Apache-2.0; check attribution | reference-link-only |

## Provenance requirements

For every dataset used in a post: record original URL, provider, type (`lab-captured` / `incident-observed` / `synthetic-test-only`), LFS SHA-256 (if supplied), collection environment, event format, timezone, license and exact events used for the detection. A true-positive label in a unit test means the detection matched that test, not a guarantee it detects every attacker technique.

## Original documentation

- https://github.com/splunk/attack_data
- https://research.splunk.com/endpoint/f5ab595e-28e5-4327-8077-5008ba97c850/
- https://research.splunk.com/stories/linux_persistence_techniques/

Source metadata checked against the GitHub repository and Splunk detection references on 2026-11-21. No log file is included by default.

## Verified LFS metadata

- SSH-key sample LFS `sha256:ee6cf8015705fc1877f27181613b2550d46be47e4853b77fb41c2f79ac48d380` (3,998 bytes).
- Cron `cronjobs_entry` sample LFS `sha256:2dbdc98578403d1636bcdab4d4214377779c17ae0ab94fab2508e30815634a7b` (59,662,955 bytes).

A metadata hash is **not** a claim the dataset was downloaded and inspected.
