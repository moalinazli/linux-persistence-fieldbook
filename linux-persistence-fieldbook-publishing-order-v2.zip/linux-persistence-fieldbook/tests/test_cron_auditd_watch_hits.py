# Explicitly synthetic fixture. This is not a captured attacker log.
import unittest
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from cron_auditd_watch_hits import parse

class TestWatchHits(unittest.TestCase):
    def test_multi_record_match(self):
        lines = [
          'type=SYSCALL msg=audit(1763212300.123:77): arch=c000003e syscall=257 success=yes comm="editor" exe="/usr/bin/editor" key="lp_cron"',
          'type=PATH msg=audit(1763212300.123:77): item=0 name="/etc/cron.d/demo" inode=12 nametype=NORMAL',
        ]
        hits=list(parse(lines))
        self.assertEqual(len(hits),1)
        self.assertEqual(hits[0]['paths'], ['/etc/cron.d/demo'])
    def test_no_matching_key(self):
        lines=['type=PATH msg=audit(1763212300.123:78): name="/etc/crontab"']
        self.assertEqual(list(parse(lines)), [])
    def test_unwatched_path(self):
        lines=['type=SYSCALL msg=audit(1763212300.123:79): key="lp_cron"',
               'type=PATH msg=audit(1763212300.123:79): name="/tmp/clean"']
        self.assertEqual(list(parse(lines)), [])

if __name__=='__main__': unittest.main()
