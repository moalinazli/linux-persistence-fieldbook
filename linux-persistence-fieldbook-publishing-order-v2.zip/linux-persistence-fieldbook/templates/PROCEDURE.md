# [Procedure ID] — [Working title]

Status: `research_backlog | source_confirmed | lab_captured | detection_tested | published`

ATT&CK ID(s): 

Environment: distro/version/kernel/desktop or service manager:

## Mechanism
What state persists? Why would it survive reboot or session interruption?

## Trigger and requirements
Trigger / user privilege / distribution dependencies.

## Exact artifacts
Paths, owner, inode/hash changes, config keys and expected contents (sanitized).

## Safe lab method
Isolated owned lab; benign marker action; baseline, observation, cleanup. Do not use live callbacks or credentials.

## Telemetry provenance
Provider, URL, genuine incident vs captured test vs synthetic, time zone, event IDs, full event boundary/correlation keys, SHA256 and licensing.

## Detection
Executable SPL/EQL/Sigma/KQL or auditable script; required sensor/version/fields and fidelity.

## FP and gaps
What normal administrative action produces the same observations? What alternate execution path evades this detector?

## Test report
Positive / negative observations; what was actually run, expected vs actual, reproducibility, version and screenshots (if genuine).

## References
Official documentation, MITRE procedure example, detection rule and original telemetry.

## Publication gate
- [ ] ATT&CK mapping confirmed
- [ ] Mechanism confirmed with primary source
- [ ] Captured telemetry inspected
- [ ] Query/run tested
- [ ] Benign control tested
- [ ] Attribution/license verified
- [ ] Cleanup verified
