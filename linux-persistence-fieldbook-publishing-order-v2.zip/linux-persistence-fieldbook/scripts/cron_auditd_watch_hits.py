#!/usr/bin/env python3
"""Extract auditd cron-path watch hits from *raw* multi-record events.

This is a baseline file-change signal, not a malware verdict. It requires
an audit rule keyed lp_cron. Event records are grouped by the same serial.
"""
from __future__ import annotations
import argparse
import re
import sys
from collections import defaultdict

SERIAL = re.compile(r'msg=audit\(([^)]+)\)')
REC_TYPE = re.compile(r'\btype=([A-Z_]+)')
PATH = re.compile(r'\bname="([^"]+)"')
COMM = re.compile(r'\bcomm="([^"]+)"')
EXE = re.compile(r'\bexe="([^"]+)"')
KEY = re.compile(r'\bkey="?([^"\s]+)"?')
WATCHED = ('/etc/crontab', '/etc/cron.d/', '/etc/cron.daily/',
           '/etc/cron.hourly/', '/etc/cron.weekly/', '/etc/cron.monthly/',
           '/var/spool/cron/')

def parse(lines):
    groups = defaultdict(lambda: {'k': False, 'p': set(), 't': set(), 'comm': set(), 'exe': set()})
    for line in lines:
        m = SERIAL.search(line)
        if not m:
            continue
        rec = groups[m.group(1)]
        rec['k'] |= bool(KEY.search(line) and KEY.search(line).group(1) == 'lp_cron')
        t = REC_TYPE.search(line)
        if t: rec['t'].add(t.group(1))
        p = PATH.search(line)
        if p and (p.group(1) == '/etc/crontab' or p.group(1).startswith(WATCHED)):
            rec['p'].add(p.group(1))
        for pattern, key in ((COMM,'comm'), (EXE,'exe')):
            val = pattern.search(line)
            if val: rec[key].add(val.group(1))
    for serial, rec in groups.items():
        if rec['k'] and rec['p']:
            yield {'audit_id':serial, 'paths':sorted(rec['p']),
                   'comm':sorted(rec['comm']), 'exe':sorted(rec['exe']),
                   'record_types':sorted(rec['t'])}

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('log',nargs='?',default='-',help='auditd text file, or - for stdin')
    args=ap.parse_args()
    if args.log=='-': stream=sys.stdin
    else: stream=open(args.log,encoding='utf-8',errors='replace')
    try:
        import json
        for hit in parse(stream): print(json.dumps(hit,ensure_ascii=False))
    finally:
        if stream is not sys.stdin: stream.close()

if __name__=='__main__': main()
