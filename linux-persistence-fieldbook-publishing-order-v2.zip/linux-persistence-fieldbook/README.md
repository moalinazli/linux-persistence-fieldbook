> Editorial update (2026-11-21): the **new** 74-episode publishing order is in [`docs/PUBLISHING_ORDER.md`](docs/PUBLISHING_ORDER.md). First article: Python `.pth` startup hooks; previous educational order archived in `catalog/publication_order_v1_educational.csv`. The topic counts are planning candidates, not verified cases.

# Linux Persistence Fieldbook

**ATT&CK mapping · reproducible procedures · observable artifacts · detection engineering**

> Status: initial public-repo package, not a finished detection library. No claims that untested detections work. No invented incident logs.

This repository answers one practical question: **what would a Linux persistence mechanism change, what would trigger it, and what would a defender actually see?**

## Scope and counting

The current MITRE ATT&CK Linux matrix lists **17 parent persistence techniques**, including **30 Linux sub-techniques**, leaving **34 terminal ATT&CK entries** when four standalone techniques are included. The CSV `catalog/linux_persistence_mitre_parents.csv` records the 17 parent techniques. These counts are **not** a count of attacker procedures; a technique may have many implementations.

The current research backlog contains **70 candidate procedures** in `catalog/procedure_backlog.csv`. Each is a *research item* until its mechanism, trigger, detection data and test results are documented. Some are adjacent cross-tactic methods useful for persistence, explicitly marked as such. The backlog is **not** 70 proven real-world incidents.

### Two classification layers

1. **Official ATT&CK:** tactic `TA0003` → parent technique → sub-technique. Source of truth: https://attack.mitre.org/matrices/enterprise/linux/
2. **Operating mechanism:** identity, scheduled execution, service, boot, interactive shell, event hook, application extension, authentication, binary/loader, server component, kernel/firmware, container and external-access. Each procedure also declares its *trigger*, *artifact*, and *telemetry*.

A `systemd timer` is **T1053.006**, not the same as a `systemd service` **T1543.002**. Shell changes, aliases and login scripts are often one ATT&CK technique, **T1546.004**, not three unrelated technique IDs. `LD_PRELOAD` belongs to **T1574.006** (cross-tactic), and setuid alone does not make a process reappear after reboot.

## The release gate

A procedure can be published as **verified** only after:

1. Verified ATT&CK mapping and primary documentation.
2. Exact trigger, permissions, artifact paths, and OS/version constraints.
3. Harmless isolated-lab reproduction, expected result and cleanup plan.
4. Raw *captured* telemetry (or an explicitly linked third-party dataset), with producer, origin, license, source hash/URL, timestamp/timezone and sourcetype.
5. One executable detection query with field prerequisites, known false positives and blind spots.
6. Test result: positive/negative checks and what failed. No invented alerts, screenshots or log lines.

**Dataset labels:** `incident-observed`, `lab-captured`, `synthetic-test-only`, `reference-link-only`. Never relabel attack-range telemetry as a real-world incident.

## What exists today

- [MITRE taxonomy](catalog/linux_persistence_mitre_parents.csv)
- [Procedure backlog](catalog/procedure_backlog.csv) — **70 candidates, zero claimed independently validated**
- [Cron dossier](techniques/T1053.003/README.md)
- [SSH authorized_keys dossier](techniques/T1098.004/README.md)
- [Systemd service dossier](techniques/T1543.002/README.md)
- [Data provenance index](datasets/SOURCES.md)
- [Auditd watch configuration](detections/auditd/cron.rules)
- [Auditd raw-event grouping detector](scripts/cron_auditd_watch_hits.py)
- [Detection test](tests/test_cron_auditd_watch_hits.py): synthetic fixtures *clearly marked*
- [Procedure template](templates/PROCEDURE.md)
- [Persian overview](README.fa.md)

## Suggested first 8 posts

1. `T1053.003`: user-crontab versus `/etc/cron.d` (two procedures, not two MITRE techniques)
2. `T1543.002`: system-level systemd service
3. `T1098.004`: user authorized_keys modification
4. `T1053.006`: systemd timer + service pair
5. `T1546.004`: `.bashrc` vs `.profile` triggers
6. `T1546.017`: udev rule creation
7. `T1546.018`: Python `.pth` startup hook
8. `T1556.003`: PAM changes with authentication event correlation

## Data rules

- Public datasets are *linked*, not silently copied or repackaged.
- Some Splunk samples are backed by Git LFS. Consult exact size before download.
- Captured test telemetry is real log data, **not** evidence of an actual victim breach.
- Logs must be redacted when they contain secrets, SSH keys, usernames or IPs belonging to third parties.

## Sources

- MITRE ATT&CK Linux matrix: https://attack.mitre.org/matrices/enterprise/linux/
- MITRE ATT&CK persistence tactic: https://attack.mitre.org/tactics/TA0003/
- MITRE systemd service detection: https://attack.mitre.org/detectionstrategies/DET0253/
- Splunk Security Content Linux persistence story: https://research.splunk.com/stories/linux_persistence_techniques/
- Splunk Attack Data: https://github.com/splunk/attack_data
- Elastic Linux detection rules: https://github.com/elastic/detection-rules
- Atomic Red Team (reproduction, **not** evidence of attacker campaign): https://github.com/redcanaryco/atomic-red-team
- Supplied study reference: HADESS, *The Art of Linux Persistence* (not republished here)

## Safety and quality

Reproduction guidance is deliberately non-destructive and aimed at owned, isolated test systems. No live backdoors, credential theft, remote shells or stealth payloads are bundled. Any rule copied from elsewhere must include license and attribution. Contributions need a working query and observed telemetry before they can claim verified coverage.


Publication sequence (70 original + 4 PDF gap candidates): [docs/PUBLISHING_ORDER.md](docs/PUBLISHING_ORDER.md). All items are research candidates, not verified attacks.
