# Contributing

One PR should add or repair **one procedure**. Do not create fake incident data, inflate procedure counts by renaming the same artifact, or map every suspicious administrative command to Persistence.

1. Pick a catalog row; identify distribution and exact trigger.
2. Cite ATT&CK and the primary source for that specific mechanism.
3. Capture and label a benign lab test. Include enough raw events for meaningful detection evaluation, or link to a licensed public dataset.
4. Provide one query and a false-positive test; measure what it misses.
5. Follow `templates/PROCEDURE.md` before asking to mark the row verified.

No network beacons, reverse-shell callbacks, credential collection or exploit binaries should be pushed to this educational defensive repo. Large or third-party log datasets should be linked with provenance instead of blindly vendored.
