# SPL references and validation requirements

This starter release deliberately **does not** ship an untested SPL rule and call it production-ready.

Useful documented detections to reproduce and tune:

- Splunk SSH-key process-based detection: https://research.splunk.com/endpoint/f5ab595e-28e5-4327-8077-5008ba97c850/
- Splunk Linux persistence analytic story: https://research.splunk.com/stories/linux_persistence_techniques/
- Splunk Linux `crontab -e` detection with raw test data: https://github.com/splunk/security_content/blob/develop/detections/endpoint/linux_edit_cron_table_parameter.yml
- Elastic file-level systemd service creation rule: https://github.com/elastic/detection-rules/blob/main/rules/linux/persistence_systemd_service_creation.toml

A detector must declare exact sourcetype, field mapping, product version, allowed test data and false-positive handling. Process-name-only SSH detections or cron-edit detections are **partial visibility**, not complete technique coverage.
